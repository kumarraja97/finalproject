let model = require('../model/booking');

booking = {};

booking.bookingTrip = (bookObj) => {
    return model.bookingTrip(bookObj).then((data) => {
        if (data === null) {
            let err = new Error("Booking not successfull");
            err.status = 404;
            throw err;
        } else {
            return data;
        }
    })
}

booking.deleteBooking = (bookingId) => {
    return model.deleteBooking(bookingId).then(bookingId => {
        if (bookingId === null) {
            let err = new Error("Could Not cancel the booking");
            err.status = 500;
            throw err;
        } else {
            return bookingId;
        }
    })
}

module.exports = booking;
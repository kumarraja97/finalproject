const express = require('express');
const router = express.Router();
const service=require('../service/packageService')

router.get('/destinations/:continent', (req, res, next) => {
    service.getDestination(req.params.continent).then(array => {
        res.json(array)
    }).catch((err) => next(err))
})
router.get('/hotDeals', (req, res, next) => {
    service.getHotdeals().then(array => {
        res.json(array)
    }).catch((err) => next(err))})

//get all destinations
router.get('/desti', (req, res, next) => {
    service.getAllDestination().then(array => {
        res.json(array)
    }).catch((err) => next(err))
})

module.exports=router;
const express = require('express');
const router = express.Router();
const booking = require('../service/booking')
const Booking = require('../model/beanClasses/booking')
const package = require('../service/packageService')

// booking
router.post('/:userId/:destinationId', (req, res, next) => {
    const newbooking = new Booking(req.body);
    let userId = req.params.userId;
    let destinationId = req.params.destinationId;
    newbooking.destinationId = destinationId;
    newbooking.userId = userId;
    booking.bookingTrip(newbooking).then((bookingObj) => {
        res.json({ "message": "Congratulations! Trip planned to " + bookingObj.destinationName  })
    }).catch((err) => { next(err) })
})

//deleteBooking
router.delete('/cancelBooking/:bookingId', (req, res, next) => {
    let bookingId = req.params.bookingId;
    booking.deleteBooking(bookingId).then(data => {
        res.json({ "message": "Successfully deleted the booking with Id: " + data})
    }).catch((err) => next(err))
})

// get destination details
router.get('/getDetails/:destinationId', (req, res, next) => {
    let destinationId = req.params.destinationId
    package.getDestinationById(destinationId).then(data => {
        res.json(data)
    }).catch((err) => next(err))
})


module.exports = router;
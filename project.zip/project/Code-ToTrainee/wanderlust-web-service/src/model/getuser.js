const connection = require("../utilities/connections")

const userdetails = {}

userdetails.getuserdb = (userid) => {
    return connection.getUserCollection().then((collection) => {
        return collection.findOne({ "userId": userid }).then((custinfo) => {
            if (custinfo) {
                console.log(custinfo)
                return custinfo;
            }
            else return null;
        })
    })
}

userdetails.deleteuserdb = (userid) => {
    return connection.getUserCollection().then((collection) => {
        return collection.deleteOne({ "userId": userid }).then((custinfo) => {
            if (custinfo) {
                console.log(userid)
                return userid;
            }
            else return null;
        })
    })
}

module.exports = userdetails;
let connection = require("../utilities/connections")

let booking = {}

booking.generateBookingId = () => {
    return connection.getBookingCollection().then((collection) => {
        return collection.distinct("bookingId").then((ids) => {
            let arr = []
            ids.forEach(data => {
                arr.push(data.substr(1))
            });
            let uId = Math.max(...arr);
            let newId = uId + 1;
            return "B" + newId;
        })
    })
}

booking.bookingTrip = (bookObj) => {
    return connection.getBookingCollection().then((data) => {
        return booking.generateBookingId().then((bookingId) => {
            bookObj.bookingId = bookingId;
            let timeStamp = new Date().getTime();
            bookObj.timeStamp = timeStamp;
            bookObj.destId = bookObj.destinationId;
            return data.insertMany([bookObj]).then((data) => {
                if (data) {
                    connection.getUserCollection().then((users) => {
                        users.updateOne({ "userId": bookObj.userId }, { $push: { bookings: bookObj.bookingId } }).then((modified) => {
                            if (modified.nModified === 1) {
                                connection.getUserDestination().then((destinations) => {
                                    destinations.findOne({ "destinationId": bookObj.destId }).then((destination) => {
                                        if (destination) {
                                            destinations.updateOne({ "destinationId": bookObj.destId }, { $inc: { availability: -bookObj.noOfPersons } })
                                        } else {
                                            connection.getUserHotdeal().then((hotdeals) => {
                                                hotdeals.findOne({ "destinationId": bookObj.destId }).then((deals) => {
                                                    if (deals) {
                                                        hotdeals.updateOne({ "destinationId": bookObj.destId }, { $inc: { availability: -bookObj.noOfPersons } })
                                                    }
                                                })
                                            })
                                        }
                                    })
                                })
                            }
                        })
                    })
                    return data
                } else {
                    return null;
                }
            })
        })
    })
}

booking.deleteBooking = (bookingId) => {
    return connection.getBookingCollection().then((data) => {
        return data.findOne({ "bookingId": bookingId }).then((bookingData) => {
            let noOfPersons = bookingData.noOfPersons;
            let destId = bookingData.destId;
            let bookid = bookingData.bookingId;
            let userId=bookingData.userId;
            if(destId.match(/^D/)){
                return connection.getUserDestination().then((destinationData) => {
                    return destinationData.findOne({ "destinationId": destId }).then(() => {
                        return destinationData.updateOne({ destinationId: destId }, { $inc: { availability: noOfPersons } }).then((updated) => {
                            if (updated.nModified === 1) {
                                return data.deleteOne({ "bookingId": bookingId }).then((deletedData) => {
                                    if (deletedData.deletedCount === 1) {
                                        connection.getUserCollection().then(userdata => {
                                            userdata.updateOne({"userId":userId},{$pull:{bookings:bookid}}).then((result)=>{
                                            })
                                       })
                                       return bookingId;
                                    }else{
                                        return null;
                                    }
                                })
                            }
                        })
                    })
                })
        }else{
            return connection.getUserHotdeal().then((destinationData) => {
                return destinationData.findOne({ "destinationId": destId }).then(() => {
                    return destinationData.updateOne({ destinationId: destId }, { $inc: { availability: noOfPersons } }).then((updated) => {
                        if (updated.nModified === 1) {
                            return data.deleteOne({ "bookingId": bookingId }).then((deletedData) => {
                                if (deletedData.deletedCount === 1) {
                                     connection.getUserCollection().then(userdata => {
                                         userdata.updateOne({"userId":userId},{$pull:{bookings:bookid}}).then((result)=>{
                                         })
                                    })
                                    return bookingId;
                                }else{
                                    return null;
                                }
                            })
                        }
                    })
                })
            })
        }

        })
    })
}

module.exports = booking;





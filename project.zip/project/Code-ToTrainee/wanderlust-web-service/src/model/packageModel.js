let connection = require("../utilities/connections")
let packageDb = {}
packageDb.getDestination = (continent) => {
    return connection.getUserDestination().then((collection) => {
        return collection.find().then(data => {
            for (let a of data) {
                if (a.continent.toLowerCase() === continent.toLowerCase()) {
                    return collection.find({ "continent": a.continent }, { _id: 0 }).then((bookings) => {
                        if (bookings.length > 0) {


                            return bookings;
                        }
                    })
                }
                else {
                    for (let b of a.details.itinerary.tourHighlights) {

                        if (b.toLowerCase() === continent.toLowerCase()) {


                            return collection.find({ "details.itinerary.tourHighlights": { $in: [b] } }, { _id: 0 }).then((bookings) => {
                                if (bookings.length > 0) {

                                    return bookings;
                                }
                            })
                        }
                    }
                }

            }

            return null;
        })
    })
}

packageDb.getAllDestinationdb = () => {
    return connection.getUserDestination().then((collection) => {
        return collection.distinct("continent").then(data => {
            
            return collection.find({},{_id:0,"details.itinerary.tourHighlights":1}).then(data1=>{
                for(let i of data1){
                    for(let j of i.details.itinerary.tourHighlights){
                        data.push(j)
                    }
                }
                
                return data;
            })
        })
    })
}


// packageDb.getAllDestinationdb()

packageDb.getHotdeal = () => {
    return connection.getUserHotdeal().then((collection) => {
        return collection.find({}, { _id: 0 }).then((bookings) => {
            if (bookings) return bookings;
            else return null;
        })
    })
}




// packageDb.getDestination("Melbourne")








packageDb.getDestinationById = (destinationId) => {
    return connection.getUserDestination().then((data) => {
        return data.findOne({ "destinationId": destinationId }).then((result) => {
            if (result) {

                return result
            } else {
                return connection.getUserHotdeal().then((data1) => {
                    return data1.findOne({ "destinationId": destinationId }).then((result2) => {
                        if (result2) {

                            return result2
                        } else {
                            return null;
                        }
                    })
                })
            }
        })
    })
}




module.exports = packageDb;
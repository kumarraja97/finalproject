const register = require('../src/model/userslogin');
const booking = require('../src/model/booking');
const packageModel = require('../src/model/packageModel');
const viewBooking = require('../src/model/viewBookings');
const package = require('../src/service/packageService');
const ViewBookService = require('../src/service/viewBookings');
const regServ = require('../src/service/userslogin')
// const request = require('request');
// const hotdealurl = "http://localhost:4000/package/hotDeals";


//booking testcases
describe('TestCase-1-Booking', () => {
    it('check Route-T', function (done) {
        let input = { userId: "U1001", destId: "D1001", destinationName: "A Week in Greece: Athens, Mykonos & Santorini", checkInDate: "2018-12-09", checkOutDate: "2018-12-16", noOfPersons: 2, totalCharges: 5998 }
        booking.bookingTrip(input).then((data) => {
            done();
            expect(data).toBeTruthy();
        }).catch(err => {
                done();
                expect(err).toBeTruthy();
            })
    })
})


describe('TestCase-2-Booking', function() {
    it('delete Booking-T',  function(done) {
            booking.deleteBooking("B1001").then((data)=>{
                    done();expect(data).toBe("B1001");
                }).catch((data)=>{
                    done();expect(data).toBe(null);
                })
    })
})

describe('search', function() {
    it('Packages-search-continent',  function(done) {
            packageModel.getDestination("Australia").then((data)=>{done();expect(data[0].name).toMatch("Grand Tour of Australia");})
    })
    it('Packages-search-tourHighlights',  function(done) {
            packageModel.getDestination("Rome").then((data)=>{done();expect(data[0].continent).toMatch("Europe");})
    })
    it('Packages-search-tourHighlights',  function(done) {
            packageModel.getDestination("Meiji Shrine, Mount Fuji").then((data)=>{done();expect(data[0].continent).toMatch("Asia");})
    })
    it('Packages-search-unavailable',  function(done) {
        package.getDestination("vijayawada").catch ((error)=>{
            expect(error).toMatch("Sorry we don't operate in this Destination");
            done();
        })
    })
    it('PlannedTrips-search-unavailable', function(done){
        package.getDestination("India").catch(err=>{
            expect(err.status).toBe(404)
            done();
        })
    })


})

describe('register', function() {
    it('check register-T', function(done){
        let users={
            "name": "kllkf",
            "emailId": "olllef@gmail.com",
            "contactNo": 6234567009,
            "password": "kklf@1234",
        }
        regServ.register(users).then((data)=>{done();expect(data).toBeDefined();})
            .catch((data)=>{done();expect(data).toBe(null);})
    })
})

describe('viewbookings', function() {
    it('PlannedTrips-T1',  function(done) {
            viewBooking.viewBookings("U1001").then((data)=>{done();expect(data[0].destinationName).toEqual('A Week in Greece: Athens, Mykonos & Santorini');})
        
    })
    it('PlannedTrips-T2',  function(done) {
            viewBooking.viewBookings("U1001").then((data)=>{done();expect(data[1].destinationName).toMatch("Romantic Europe: Paris, Venice & Vienna");})
        
    })
    it('PlannedTrips-T3',  function(done){
            viewBooking.viewBookings("U1002").then((data)=>{done();expect(data[0].bookingId).toMatch("B1003");})
        
    })
    it('PlannedTrips-UnavailableUser-F1',  function(done) {
        ViewBookService.getBookingData("U1035").then((data)=>{})
        .catch( (error) =>{
            expect(error).toMatch("Sorry You have not planned any trips with us yet!");
            done();
        })
    })
    it('PlannedTrips-UnavailableUser-F2', function(done){
        ViewBookService.getBookingData("U1046").catch(err=>{
            expect(err.status).toBe(404)
            done();
        })
    })
})
//login
describe('TestCase-1-Login',()=>{
    it('checking Password-T', function(done){
        register.getPassword(9098765432).then((password)=>{done();expect(password).toMatch(/[A-Za-z0-9]+[!,@,#,$,%,^,&,*]/);})
    })
    it('checking logged user-T', function(done){
        regServ.login(9098765432,"Abc@1234").then((loggeddetails)=>{done();expect(loggeddetails).toBeDefined()})
    })
 })

//hotdeals
 describe('TestCase-1-Hotdeals', function() {
    it('checking model  HotDeal-T',  function(done) {
          packageModel.getHotdeal().then((data)=>{done();expect(data).toBeDefined();})
    })
    it('checking regServ HotDeal-T',  function(done) {
          package.getHotdeals().then((data)=>{done();expect(data).toBeDefined();})
    })
 })

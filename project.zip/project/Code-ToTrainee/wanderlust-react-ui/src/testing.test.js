import React from 'react';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
configure({ adapter: new Adapter() });
import { shallow } from 'enzyme';

import Home from './home';
import Login from './login';
import Register from './register';
import Booking from './booking';
import Packages from './packages';


describe('Home Component', () => {
    test("Form in home", () => {
        const wrapper = shallow(<Home />);
        expect(wrapper.find("form")).toEqual(1);
    });
})

describe("Login Component", () => {
    test("Form in login", () => {
        const wrapper = shallow(<Login />);
        expect(wrapper.find("form")).toHaveLength(1);
    });
    test("Login has two input fields", () => {
        const wrapper = shallow(<Login />);
        expect(wrapper.find("form").find("input")).toHaveLength(2);
    })
    test("Login has two buttons", () => {
        const wrapper = shallow(<Login />);
        expect(wrapper.find("form").find("button")).toHaveLength(1);
    })

});
describe("Register Component", () => {
    test("Form in login", () => {
        const wrapper = shallow(<Register />);
        expect(wrapper.find("form")).toHaveLength(1);
    });
    test("Register has four input fields plus one button", () => {
        const wrapper = shallow(<Register />);
        expect(wrapper.find("form").find("input").length + wrapper.find("form").find("button").length).toBe(5);
    })
});

describe("packages component",()=>{
    test("Check sidebar",()=>{
        const wrapper=shallow(<Packages/>);
        exxpect(wrapper.find("Sidebar").length).toEqual(1);
    });
    test("No of Persons validation more",()=>{
        const wrapper=shallow(<Packages/>);
        wrapper.instance().validateField("noOfPersons",9)
        exxpect(wrapper.state().bookingFormErrorMEssage.noOfPersons).toEqual("No. of persons can't be more than 5.")
    });
    test("No of Persons validation less",()=>{
        const wrapper=shallow(<Packages/>);
        wrapper.instance().validateField("noOfPersons",0)
        exxpect(wrapper.state().bookingFormErrorMEssage.noOfPersons).toEqual("No. of persons can't be less than 1!")
    });
    test("Check Scrollpanel",()=>{
        const wrapper=shallow(<Packages/>);
        exxpect(wrapper.find("ScrollPanel").length).toEqual(1);
    });
})

``
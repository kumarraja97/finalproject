import React, { Component } from 'react';
import axios from "axios";
import { backendUrlUser } from '../BackendURL';
import { backendUrlBooking } from '../BackendURL';
import { Panel } from 'primereact/panel';
import { Link } from "react-router-dom";
import { Dialog } from 'primereact/dialog';
import { ProgressSpinner } from 'primereact/progressspinner';
import {Growl} from 'primereact/growl';



class viewBookings extends Component {

    constructor() {
        super();
        this.state = {
            bookingDetails: [],
            errorMessage: "",
            visible: false,
            bookingId: "",
            show: true,
            alertvalid:false,
            successMessage:"",
        }
        this.onClick = this.onClick.bind(this);
        this.onHide = this.onHide.bind(this);
    }
    onClick() {
        this.setState({ visible: true });
    }

    onHide() {
        this.setState({ visible: false });
    }
    componentDidMount = () => {
        let userId = sessionStorage.getItem("userId");
        this.setState({ bookingDetails: [], errorMessage: "" });
        axios.get(backendUrlUser + "/getBookings/" + userId).then((response) => {
            this.setState({ bookingDetails: response.data, errorMessage: "", show: false });

        })
            .catch((error) => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message, bookingDetails: [], show: false })
                } else {
                    this.setState({ errorMessage: "Server Error", bookingDetails: [], show: false })
                }
            })

    }
    delete = (bookingId) => {
        console.log(bookingId)
        axios.delete(backendUrlBooking + "/cancelBooking/" + bookingId)
            .then((response) => {console.log(response);this.setState({successMessage:response.data.message,show:true});this.showSuccess();this.componentDidMount();})
            .catch((error) => { this.setState({errorMessage:error.response,alertvalid:true})})
    }
    handleDelete = (bookingId) => {
        this.setState({ visibleFullScreen: true });
    }
    showSuccess() {
        this.growl.show({severity: 'success', summary: 'Successfully Deleted',detail:this.state.successMessage});
    }
    render() {
        let bookingId = this.state.bookingId;
        const footer = (
            <div>
                <button className="btn btn-primary" onClick={this.onHide}>BACK</button>
                <button className="btn btn-secondary" onClick={() => { this.onHide(); this.delete(bookingId) }}>CONFIRM CANCELATION</button>
            </div>
        );

        return (
            <React.Fragment>
                {this.state.alertvalid?<div>{alert('{this.state.errorMessage}')}</div>:null}
                <Growl ref={(el) => this.growl = el} position="center"></Growl>
                {this.state.show ? (
                    <div id="details" className="details-section">
                        <div className="text-center">
                            <ProgressSpinner></ProgressSpinner>
                        </div>
                    </div>) :
                    <div>
                        {sessionStorage.getItem("userId") ?
                            [this.state.bookingDetails.length === 0 ? <div>
                                <div className="text-center">
                                    <h2>Sorry You have not planned any trips with us yet!</h2><br />
                                    <a href="http://localhost:3000/home" className="btn btn-primary btn-lg mx-auto">CLICK HERE TO START BOOKING</a>
                                </div>
                                <br />
                            </div> : this.state.bookingDetails.map((data) => {
                                return (
                                    <div key={data.bookingId} className="card row">
                                        <div className="card-body col-md-8 offset-2">
                                            <Panel header={"Booking Id: " + data.bookingId} className="text-left">
                                                <div className="row" >
                                                    <div className="col-md-8"  >
                                                        <div ><h4>{data.destinationName}</h4></div>
                                                        <div className="row">
                                                            <div className="col-md-6">
                                                                <div>Trip starts on:{data.checkInDate}</div>
                                                                <div>trip ends on:{data.checkOutDate}</div>
                                                                <div>Travellers:{data.noOfPersons}</div>
                                                            </div>
                                                            <div className="col-md-6">                    
                                                                <div>Fare Details</div>
                                                                <div>${data.totalCharges}</div>
                                                                <Link onClick={() => { this.onClick(); this.setState({ "bookingId": data.bookingId }) }} to="/viewBookings"><h6>Claim refund</h6></Link>
                                                                {(this.state.visible ? <Dialog header="Confirm Cancellation" visible={this.state.visible} style={{ width: '50vw' }} footer={footer} onHide={this.onHide} maximizable>
                                                                    <div className="text-danger">Are you sure you want to cancel trip to {data.destinationName}</div>
                                                                    <div>Trip starts on:{data.checkInDate}</div>
                                                                    <div>trip ends on:{data.checkOutDate}</div>
                                                                    <div>Refund Amount:${String(data.totalCharges)[0]},{String(data.totalCharges).substring(1)}.00</div>
                                                                </Dialog> : null)}
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div className="col-md-4">
                                                        <img className="package-image" src={data.imageUrl} style={{width: '225px', height: '150px'}} alt="destination comes here" />
                                                    </div>
                                                    
                                                </div>
                                            </Panel>
                                            <div></div>
                                        </div>
                                    </div>)
                            })] : (
                                <div>
                                    <div className="text-center">
                                        <h2 className="text-info">Please Login</h2><br />
                                        <a href="http://localhost:3000/login" className="btn btn-primary btn-lg mx-auto">CLICK HERE TO LOGIN</a>
                                    </div>
                                    <br />
                                </div>

                            )}</div>
                }
            </React.Fragment>
        );
    }
}

export default viewBookings;